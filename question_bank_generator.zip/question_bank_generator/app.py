import json
import random
import ollama
from datetime import datetime

class AIQuestionBankGenerator:
    def __init__(self, model="qwen2-math:1.5b"):
        self.model = model
        self.question_bank = {}
        self.templates = {
            "mcq": "Generate {num} multiple choice questions about {topic} for {difficulty} level. Each question should have 4 options and one correct answer.",
            "true_false": "Generate {num} true/false questions about {topic} for {difficulty} level, including correct answers.",
            "short": "Generate {num} short answer questions about {topic} for {difficulty} level, with brief model answers.",
            "long": "Generate {num} long answer questions about {topic} for {difficulty} level, including key points."
        }

    def generate_questions(self, topic, difficulty, q_type, num):
        if q_type not in self.templates:
            raise ValueError(f"Unsupported question type: {q_type}")

        prompt = self.templates[q_type].format(topic=topic, difficulty=difficulty, num=num)
        try:
            response = ollama.chat(model=self.model, messages=[{"role": "user", "content": prompt}])
            return response["message"]["content"].split('\n')
        except Exception as e:
            print("Error generating questions:", e)
            return []

    def add_to_bank(self, topic, difficulty, q_type, questions):
        self.question_bank.setdefault(topic, {}).setdefault(difficulty, {}).setdefault(q_type, []).extend(questions)
        print(f"Added {len(questions)} {q_type} questions to bank.")

    def save_question_bank(self, filename="question_bank.json"):
        with open(filename, "w") as f:
            json.dump(self.question_bank, f, indent=2)
        print(f"Question bank saved to {filename}")

    def generate_exam_paper(self, topic, difficulty, num_mcq=5, num_tf=3, num_short=2, num_long=1):
        exam_paper = {"title": f"{topic} Exam ({difficulty} Level)", "date": datetime.now().strftime("%Y-%m-%d"), "sections": []}
        
        for q_type, num in {"mcq": num_mcq, "true_false": num_tf, "short": num_short, "long": num_long}.items():
            if topic in self.question_bank and difficulty in self.question_bank[topic] and q_type in self.question_bank[topic][difficulty]:
                questions = random.sample(self.question_bank[topic][difficulty][q_type], min(num, len(self.question_bank[topic][difficulty][q_type])))
                exam_paper["sections"].append({"type": q_type, "questions": questions})
        
        return exam_paper

# Example Usage
generator = AIQuestionBankGenerator()
topic = "Machine Learning"
difficulty = "beginner"

for q_type in ["mcq", "true_false", "short", "long"]:
    questions = generator.generate_questions(topic, difficulty, q_type, 3)
    generator.add_to_bank(topic, difficulty, q_type, questions)

generator.save_question_bank()
exam = generator.generate_exam_paper(topic, difficulty)
print(json.dumps(exam, indent=2))
