import gradio as gr
import json
from app import AIQuestionBankGenerator

# Initialize generator
generator = AIQuestionBankGenerator()

# Helper functions to format the display
def format_question(question, q_type):
    if not question or question.strip() == "":
        return ""
    
    formatted = question.strip()
    
    # Add some styling based on question type
    if q_type == "mcq":
        # Format MCQ questions
        formatted = formatted.replace("**Question**:", "<b>Question:</b>")
        formatted = formatted.replace("**Option A**:", "<b>A:</b>")
        formatted = formatted.replace("**Option B**:", "<b>B:</b>")
        formatted = formatted.replace("**Option C**:", "<b>C:</b>")
        formatted = formatted.replace("**Option D**:", "<b>D:</b>")
        formatted = formatted.replace("**Answer**:", "<b>Answer:</b>")
    elif q_type == "true_false":
        # Format true/false questions
        if "- True" in formatted:
            formatted = formatted.replace("- True", "<b>Answer: True</b>")
        elif "- False" in formatted:
            formatted = formatted.replace("- False", "<b>Answer: False</b>")
    elif q_type == "short" or q_type == "long":
        # Format short/long answer questions
        formatted = formatted.replace("**Question:**", "<b>Question:</b>")
        formatted = formatted.replace("**Short Answer Answer:**", "<b>Answer:</b>")
        
    return formatted.replace("\n", "<br>")

def format_exam_paper(exam_data):
    try:
        if isinstance(exam_data, str):
            exam = json.loads(exam_data)
        else:
            exam = exam_data
            
        html = f"<h2>{exam['title']}</h2>"
        html += f"<p>Date: {exam['date']}</p><hr>"
        
        for section_idx, section in enumerate(exam['sections']):
            q_type = section['type']
            html += f"<h3>Section {section_idx + 1}: "
            
            if q_type == "mcq":
                html += "Multiple Choice Questions</h3>"
            elif q_type == "true_false":
                html += "True/False Questions</h3>"
            elif q_type == "short":
                html += "Short Answer Questions</h3>"
            elif q_type == "long":
                html += "Long Answer Questions</h3>"
            
            for i, question in enumerate(section['questions']):
                html += f"<div style='margin-bottom:15px; padding:10px; border:1px solid #ddd; border-radius:5px;'>"
                html += format_question(question, q_type)
                html += "</div>"
                
        return html
    except Exception as e:
        return f"<p>Error formatting exam: {str(e)}</p><pre>{exam_data}</pre>"

def format_question_bank():
    try:
        # Load the question bank
        with open("question_bank.json", "r") as f:
            question_bank = json.load(f)
        
        html = "<h2>Question Bank Contents</h2>"
        
        for topic in question_bank:
            html += f"<h3>Topic: {topic}</h3>"
            
            for difficulty in question_bank[topic]:
                html += f"<h4>Difficulty: {difficulty}</h4>"
                
                for q_type in question_bank[topic][difficulty]:
                    if q_type == "mcq":
                        type_name = "Multiple Choice Questions"
                    elif q_type == "true_false":
                        type_name = "True/False Questions"
                    elif q_type == "short":
                        type_name = "Short Answer Questions"
                    elif q_type == "long":
                        type_name = "Long Answer Questions"
                    else:
                        type_name = q_type
                        
                    html += f"<h5>{type_name} ({len(question_bank[topic][difficulty][q_type])} questions)</h5>"
                    
                    for i, question in enumerate(question_bank[topic][difficulty][q_type]):
                        if question.strip():  # Skip empty questions
                            html += f"<div style='margin-bottom:15px; padding:10px; border:1px solid #ddd; border-radius:5px;'>"
                            html += format_question(question, q_type)
                            html += "</div>"
        
        return html
    except Exception as e:
        return f"<p>Error loading question bank: {str(e)}</p>"

# Main functions
def generate_and_add(topic, difficulty, mcq, tf, short, long):
    results = []
    for q_type, num in {"mcq": mcq, "true_false": tf, "short": short, "long": long}.items():
        if num > 0:
            questions = generator.generate_questions(topic, difficulty, q_type, int(num))
            generator.add_to_bank(topic, difficulty, q_type, questions)
            results.append(f"Added {len(questions)} {q_type} questions")
    
    # Return both text feedback and formatted question bank
    return "\n".join(results), format_question_bank()

def create_exam(topic, difficulty, mcq, tf, short, long):
    exam = generator.generate_exam_paper(topic, difficulty, int(mcq), int(tf), int(short), int(long))
    # Return both raw JSON and formatted HTML
    return json.dumps(exam, indent=2), format_exam_paper(exam)

def save_bank():
    generator.save_question_bank()
    return "Question bank saved!", format_question_bank()

# Define the Gradio interface
with gr.Blocks() as demo:
    gr.Markdown("# AI Question Bank Generator")
    
    with gr.Row():
        topic = gr.Textbox(label="Topic", value="Machine Learning")
        difficulty = gr.Dropdown(["beginner", "intermediate", "advanced"], label="Difficulty", value="beginner")
    
    with gr.Row():
        mcq = gr.Number(label="MCQs", value=5)
        tf = gr.Number(label="True/False", value=3)
        short = gr.Number(label="Short Answer", value=2)
        long = gr.Number(label="Long Answer", value=1)
    
    with gr.Tabs():
        with gr.TabItem("Generate Questions"):
            generate_btn = gr.Button("Generate Questions")
            text_output = gr.Textbox(label="Status")
            formatted_bank = gr.HTML(label="Question Bank")
            generate_btn.click(generate_and_add, 
                              inputs=[topic, difficulty, mcq, tf, short, long],
                              outputs=[text_output, formatted_bank])
        
        with gr.TabItem("Create Exam"):
            exam_btn = gr.Button("Create Exam")
            json_output = gr.Textbox(label="Raw JSON")
            formatted_exam = gr.HTML(label="Formatted Exam")
            exam_btn.click(create_exam, 
                          inputs=[topic, difficulty, mcq, tf, short, long],
                          outputs=[json_output, formatted_exam])
        
        with gr.TabItem("Question Bank"):
            save_btn = gr.Button("Save & View Question Bank")
            save_status = gr.Textbox(label="Status")
            bank_view = gr.HTML(label="Question Bank Contents")
            save_btn.click(save_bank, 
                         inputs=[],
                         outputs=[save_status, bank_view])

# Launch the app
demo.launch()