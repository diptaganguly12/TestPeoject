import gradio as gr
import json  # Add this import
from app import AIQuestionBankGenerator

generator = AIQuestionBankGenerator()

def generate_and_add(topic, difficulty, mcq, tf, short, long):
    results = []
    for q_type, num in {"mcq": mcq, "true_false": tf, "short": short, "long": long}.items():
        if num > 0:
            questions = generator.generate_questions(topic, difficulty, q_type, int(num))
            generator.add_to_bank(topic, difficulty, q_type, questions)
            results.append(f"Added {len(questions)} {q_type} questions")
    return "\n".join(results)

def create_exam(topic, difficulty, mcq, tf, short, long):
    exam = generator.generate_exam_paper(topic, difficulty, int(mcq), int(tf), int(short), int(long))
    return json.dumps(exam, indent=2)  # Now json will be defined

with gr.Blocks() as demo:
    gr.Markdown("# AI Question Bank Generator")
    with gr.Row():
        topic = gr.Textbox(label="Topic", value="Machine Learning")
        difficulty = gr.Dropdown(["beginner", "intermediate", "advanced"], label="Difficulty", value="beginner")
    
    with gr.Row():
        mcq = gr.Number(label="MCQs", value=5)
        tf = gr.Number(label="True/False", value=3)
        short = gr.Number(label="Short Answer", value=2)
        long = gr.Number(label="Long Answer", value=1)
    
    with gr.Row():
        generate_btn = gr.Button("Generate Questions")
        exam_btn = gr.Button("Create Exam")
        save_btn = gr.Button("Save Question Bank")
    
    output = gr.Textbox(label="Output")
    
    generate_btn.click(generate_and_add, [topic, difficulty, mcq, tf, short, long], output)
    exam_btn.click(create_exam, [topic, difficulty, mcq, tf, short, long], output)
    save_btn.click(lambda: generator.save_question_bank(), None, output)

demo.launch()